<!DOCTYPE html>
<html>
<head>
    <title>Bnagladesh Railway</title>
<style >
    .table{
       background-color: gray;
    }
    .inner1{
        height: 100%;
        width: 100%;
        background-color :#193a44;
        color:white;
        
    }
    .inner2{
        width :100%;
      height :100%;
    background-color:#888787;
        
    }

    h1 {
text-align : left;
text-shadow : 2px 3px 5px black;
font : uppercase;;
font-weight : bold;
font-size : 30px;
letter-spacing : 4px;
word-spacing : 7px;

}

    .inner2 a{
      color:white;
      text-decoration:none;
      background-color:#1a1b1c;
      }
     .inner2 a:hover{
      color:#888787;
      text-decoration:underline;
      font-size:30px;  
          background-color:black;
      }
      .inner2 a:after{
               content:"";
               position :absolute;
               top:-50%;
               right:0;
               width:0;
               height:1px;
               background-color:#000;
               transition :all 0.5s linear;
       
       }
       .inner2 a:hover:after{
          width :100%;
           background-color:#7158e2;
       
       }


p{
  text-align :center;
  background-color :;
  font-size :20px;


}
.inner3{
    color: black;
            height: 500px;
            width: 600px;
            background-color:#EFF5EA;
            text-align :center;
            font-size: 20px;
  
    

}
input{
  padding :5px  10px ;
  margin : 10px;
  border-radius :19px;


  
  }
  body{
    height: 100%;
    width: 100%;
  }
  .inner4{
    font-size: 20px;
  }
</style>    

    
</head>
<body bgcolor="#EFF5EA";>
    <div class="inner1"> 
                  <table>
                      <tr>
                        <td>
                              <img src="logo.png" alt="logo.png">
                            
                        </td>
                          <td> <h1 align="center"> Bangladesh Railway
        <br>
        E-TICKETING SERVICE
        </h1>
</td>
                      </tr>

                  </table>
            
                    
            
           
        
    </div>
    <div class="inner2">
        <p>             
 <a href = "homepage.php"> Welcome   </a>&nbsp;
<a href = "farequery.php"> Farequery </a>&nbsp;
<a href = "trainroute.php"> Train Route </a>&nbsp;
<a href = "purchaseticket.php"> Purchase Ticket </a>&nbsp;
<a href = "purchasehistory.php"> Purchase History </a>&nbsp;
<a href = "profile.php"> Profile</a>&nbsp;
<a href = "changepassword.php"> Change Password </a>&nbsp;
<a href = "contact.php">Contact</a>&nbsp;
<a href = "signout.php">Sign Out</a>&nbsp;
   </div>
       
   


<table style="width:100% " border="1" bgcolor="gray">
  <tr style="font-size: 2em; color: #290e15; ">
    <th>Train Name</th>
    <th>Train Code</th> 
    <th>Train Type</th>
    <th>Off Day</th>
  </tr>
  <tr align="center">
    <td>Turna Express </td>
    <td>742</td>
    <td>Intercity</td>
     <td>No </td>
  
  </tr>
  <tr align="center">
     <td>Mahanagar Express </td>
    <td>704</td>
    <td>Intercity</td>
     <td>No </td>
  </tr>
  <tr align="center">
    <td>Parabat Express </td>
    <td>708</td>
    <td>Intercity</td>
     <td>Tuesday </td>
    
    
  </tr>
   <tr align="center">
    <td>Titas Commuter </td>
    <td>36</td>
    <td>mail</td>
     <td>No</td>
    
    
  </tr>
</table>


<form>
      <fieldset style="border: black 1px solid; background-color: gray; border-width :10px 10px 10px 10px;
      border-radius : 1px;
" >  
<h1>  Search Train </h1>
      <div class="inner4">
      
       STATION FROM &nbsp; :&nbsp; &nbsp;<select name="station from">
    <option value="">**None**</option>
    <option value="saab">Dhaka</option>
    <option value="fiat">Jamalpur</option>
    <option value="audi">Cumilla</option>
  </select> <br> <br>
     
       STATION TO &nbsp; :&nbsp; &nbsp; <select name="station to">
    <option value="">**None**</option>
    <option value="saab">Dhaka</option>
    <option value="fiat">Jamalpur</option>
    <option value="audi">Comilla</option>
  </select><br> <br>
  <input type="submit" name="Show Train" value="Show Train" style="background-color:Green;color:white; padding: 10px 10px;text-align: center;margin-right:40em ;font-size:15px;cursor: pointer;">


     </div>
        


      </fieldset>
    </form>

</body>
</html>