<!DOCTYPE html>
<html>
<head>
    <title>Bnagladesh Railway</title>
<style >
    .table{
       background-color:gray ;
    }
    .inner1{
        height: 100%;
        width: 100%;
        background-color :#193a44;
        color:white;
        
    }
    .inner2{
        width :100%;
      height :100%;
    background-color:#888787;
        
    }

    h1 {
text-align : center;
text-shadow : 2px 3px 5px black;
font : uppercase;;
font-weight : bold;
font-size : 30px;
letter-spacing : 4px;
word-spacing : 7px;

}

    .inner2 a{
      color:white;
      text-decoration:none;
      background-color:#1a1b1c;
      }
     .inner2 a:hover{
      color:#888787;
      text-decoration:underline;
      font-size:30px;  
          background-color:black;
      }
      .inner2 a:after{
               content:"";
               position :absolute;
               top:-50%;
               right:0;
               width:0;
               height:1px;
               background-color:#000;
               transition :all 0.5s linear;
       
       }
       .inner2 a:hover:after{
          width :100%;
           background-color:#7158e2;
       
       }


p{
  text-align :center;
  background-color :;
  font-size :20px;


}
.inner3{
    color: black;
            height: 500px;
            width: 600px;
            background-color:#EFF5EA;
            text-align :center;
            font-size: 20px;
  
    

}
input{
  padding :5px  10px ;
  margin : 10px;
  border-radius :19px;


  
  }
  body{
    height: 100%;
    width: 100%;
  }
</style>    

    
</head>
<body bgcolor="#EFF5EA";>
    <div class="inner1"> 
                  <table>
                      <tr>
                        <td>
                              <img src="logo.png" alt="logo.png">
                            
                        </td>
                          <td> <h1 align="center"> Bangladesh Railway
        <br>
        E-TICKETING SERVICE
        </h1>
</td>
                      </tr>

                  </table>
            
                    
            
           
        
    </div>
    <div class="inner2">
        <p>

            
 <a href = "homepage.php"> Welcome   </a>&nbsp;
<a href = "farequery.php"> Farequery </a>&nbsp;
<a href = "trainroute.php"> Train Route </a>&nbsp;
<a href = "purchaseticket.php"> Purchase Ticket </a>&nbsp;
<a href = "purchasehistory.php"> Purchase History </a>&nbsp;
<a href = "profile.php"> Profile</a>&nbsp;
<a href = "changepassword.php"> Change Password </a>&nbsp;
<a href = "contact.php">Contact</a>&nbsp;
<a href = "signout.php">Sign Out</a>&nbsp;
        </p>
        
    </div>

    <div class="inner3">
        <table align="center" class="table">
            <tr>
                <tr> &nbsp; &nbsp; <br><tr>
                <td>
                    <fieldset>  <h1> <u>QUICK FARE QUERY </u></h1>
               
               Journey From <br> <br>
              ;<select name="jfrom">
    <option value="">**None**</option>
    <option value="dhaka">Dhaka</option>
    <option value="Comilla">Comilla</option>
    <option value="jamalpur">Jmalpur</option>
  </select>  <br><br>

               Journey To <br> <br>
           ;<select name="jto">
    <option value="">**None**</option>
    <option value="dhaka">Dhaka</option>
    <option value="comilla">Comilla</option>
    <option value="jamalpur">Jmalapur</option>
  </select>  <br>   
               
                 <br>
              
               Journey Date <br> 
               <input type="date" size="20" name="jdate"> <br>

               Journey Time <br> 
               <input type="time" size="20" name="jtime"> <br>

               Available Train <br> <br>
               ;<select name="atrain">
    <option value="">**None**</option>
    <option value="dhaka">dhaka</option>
    <option value="comilla">comilla</option>
    <option value="jamalpur">jamalpur</option>
  </select>  <br><br>

               Class <br><br> <select name="class"> 
    <option value="">**None**</option>
    <option value="ac">ac</option>
    <option value="shovon">shovon</option>
    <option value="s-chair">s-chair</option>
  </select> 
                 <br>
                


                    
                </td>
                
            </fieldset>

            <td>
              <fieldset>  <h1> <u>Calculate Fare Cost </u></h1>
                No Of Seat <br><br>
                <select name="nos"> 
    <option value="">**None**</option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
  </select> <br> <br>
  BDT(BDT) <br><br>
  <input type="text" name="bdt"> <br><br>
  Vat(%) <br><br>
  <input type="text" name="vat" value="2"> <br><br>
    Net Bill(BDT) <br><br>
  <input type="text" name="nb"> <br><br>

               

              
            </td>
          </tr>
        </table>

    </div>    
    <input type="submit" name="refresh" value="Refresh" style="background-color:red;color:white; padding: 10px 30px ;text-align: right;margin-left:44em ;font-size:15px;cursor: pointer;"> &nbsp;
    

</body>



                 