<!DOCTYPE html>
<html>
<head>
	<title>Bngladesh Railway</title>
	<style >
		body{
			background:url('background.jpg')no-repeat;
			background-size: cover; 
		}
	
		
    h1 {
text-align : left;
text-shadow : 2px 3px 5px white;
font : uppercase;;
font-weight : bold;
font-size : 30px;
letter-spacing : 4px;
word-spacing : 7px;

}
.input {
  background-color: #4CAF50;
  border: ;
  border-color: red;
  color: white;
  padding: 10px 20px;
  text-align: center;
  
  font-size: 12px;

  
} 

.input1 {
  background-color: gray;
  border: ;
  border-color: red;
  color: white;
  padding: 10px 20px;
  text-align: center;
  
  font-size: 12px;

  
}  
	</style>
</head>
<body bgcolor="#EFF5EA";>
<table>
	<tr>
		<td>
	
</tr>

	</table>

	
	<table width="100%" height="100%">
		<div class="inner1"> 

	<tr>
		<td>
			  <img src="logo.png" alt="logo.png">

                        </td>
                           <h1> <td> <h1>Bangladesh Railway </h1></td>
       
      
        </h1>                            
		
		<td height="100%" width="100%">
			
			
		</td>
		
	</tr>
</div>
	</table>
	<img src="contact.png" width="100%" height="100px;">
	<div style="background-color: ; height: 50px; width: 100%;" >
		<p style="font-size: 30px; color: white;" align="center"> <b>Contact Us </b></p>

		
	</div>

</div> <div style="color:red;"><b> &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;COMPLAIN BOX:</b></div>
<br>
<div style="color: red; font-size: 20px;" >
	<tr>
	<td>
		  <textarea name="message" rows="10" cols="30"></textarea>
  <br>
  <br>
  <input type="submit" name="submit" class="input">

  <input type="button" value="Back!" class="input1"> 
	 </td>
  

</tr>
	
</div>
</body>
</html>